
package assignment;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {

    public static void main(String[] args) {
    
    //Scanner objects
        Scanner scanInt = new Scanner(System.in);
        Scanner scanString = new Scanner(System.in);
        Scanner scanChar = new Scanner(System.in);

    //User Input Section    
        System.out.println("*** Movie Registration Process ***");
        System.out.println("__________________________________");
        
        System.out.println("[@] Enter Movie Inforation:");
        System.out.println("    Movie Name:");
        String m_name = scanString.nextLine();
        System.out.println("    Movie Category:");
        String m_category = scanString.nextLine();
        System.out.println("    Movie Release Year:");
        int m_releaseYear = scanInt.nextInt();
        System.out.println("    Movie Durattion in minutes:");
        int m_duration_min = scanInt.nextInt();
    
    //Dynamic Cast Info Input    
        ArrayList <Cast> castList = new ArrayList<>();
        String castChoice;
        System.out.println("\n[@] Enter Cast Inforation:");
        do {            
            System.out.println("    Cast Name:");
            String cast_name = scanString.nextLine();
            System.out.println("    Cast Roll:");
            String cast_roll = scanString.nextLine();
            
            castList.add(new Cast(cast_name, cast_roll));
            
            System.out.println("    [?] Add another cast info? (y/n)");
            castChoice = scanChar.next();
            
        } while (castChoice.equalsIgnoreCase("y"));
    
    //Dynamic Crew Info Input            
        ArrayList <Crew> crewList = new ArrayList<>();
        String crewChoice;
        System.out.println("\n[@] Enter Crew Inforation:");
        do {            
            System.out.println("    Crew Name:");
            String crew_name = scanString.nextLine();
            System.out.println("    Crew Position:");
            String crew_position = scanString.nextLine();
            
            crewList.add(new Crew(crew_name, crew_position));
            
            System.out.println("    [?] Add another crew info? (y/n)");
            crewChoice = scanChar.next();
            
        } while (crewChoice.equalsIgnoreCase("y"));
    
    //Assign Movie Properties
        Movie movie = new Movie();
        movie.setM_name(m_name);
        movie.setM_category(m_category);
        movie.setM_releaseYear(m_releaseYear);
        movie.setM_duration_min(m_duration_min);
        movie.setCast(castList);
        movie.setCrew(crewList);       
        
        ArrayList <Movie> movieList = new ArrayList<>();       
        movieList.add(movie);
    
    //Printed Details
        System.out.println("\n\n_____Full Details_____");
        for (Movie m : movieList){
            System.out.println(m);
        }
        
    }
    
}
