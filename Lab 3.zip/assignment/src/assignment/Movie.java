
package assignment;

import java.util.ArrayList;

public class Movie {
    
    private String m_name;
    private String m_category;
    private int m_releaseYear;
    private int m_duration_min;
    
    ArrayList <Cast> cast;
    ArrayList <Crew> crew;

    public void setM_name(String m_name) {
        this.m_name = m_name;
    }

    public void setM_category(String m_category) {
        this.m_category = m_category;
    }

    public void setM_releaseYear(int m_releaseYear) {
        this.m_releaseYear = m_releaseYear;
    }

    public void setM_duration_min(int m_duration_min) {
        this.m_duration_min = m_duration_min;
    }

    public void setCast(ArrayList<Cast> cast) {
        this.cast = cast;
    }

    public void setCrew(ArrayList<Crew> crew) {
        this.crew = crew;
    }

    public String getM_name() {
        return m_name;
    }

    public String getM_category() {
        return m_category;
    }

    public int getM_releaseYear() {
        return m_releaseYear;
    }

    public int getM_duration_min() {
        return m_duration_min;
    }

    public ArrayList<Cast> getCast() {
        return cast;
    }

    public ArrayList<Crew> getCrew() {
        return crew;
    }

    @Override
    public String toString() {
        return "Movie{" + "m_name=" + m_name + ", m_category=" + m_category + ", m_releaseYear=" + m_releaseYear + ", m_duration_min=" + m_duration_min + ", cast=" + cast + ", crew=" + crew + '}';
    }
    
    
}
