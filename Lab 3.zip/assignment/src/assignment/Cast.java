
package assignment;

public class Cast {
    
    private String cast_name;
    private String cast_roll;

    public Cast(String cast_name, String cast_roll) {
        this.cast_name = cast_name;
        this.cast_roll = cast_roll;
    }

    public void setCast_name(String cast_name) {
        this.cast_name = cast_name;
    }

    public void setCast_roll(String cast_roll) {
        this.cast_roll = cast_roll;
    }

    public String getCast_name() {
        return cast_name;
    }

    public String getCast_roll() {
        return cast_roll;
    }

    @Override
    public String toString() {
        return "Cast{" + "cast_name=" + cast_name + ", cast_roll=" + cast_roll + '}';
    }
    
    
}
