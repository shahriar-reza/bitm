
package assignment;

public class Crew {
    
    private String crew_name;
    private String crew_position;

    public Crew(String crew_name, String crew_position) {
        this.crew_name = crew_name;
        this.crew_position = crew_position;
    }

    public void setCrew_name(String crew_name) {
        this.crew_name = crew_name;
    }

    public void setCrew_position(String crew_position) {
        this.crew_position = crew_position;
    }

    public String getCrew_name() {
        return crew_name;
    }

    public String getCrew_position() {
        return crew_position;
    }

    @Override
    public String toString() {
        return "Crew{" + "crew_name=" + crew_name + ", crew_position=" + crew_position + '}';
    }
    
    
}
