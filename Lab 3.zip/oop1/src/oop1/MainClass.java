
package oop1;

import java.util.ArrayList;


public class MainClass {

    
    public static void main(String[] args) {
        
        Student s1 = new Student();
        StudentAddress address1 = new StudentAddress();
        StudentContact contact1 = new StudentContact();
        StudentDepartment department1 = new StudentDepartment();
        ArrayList<Course> courses = new ArrayList<>();
        
        address1.setCity("Dhaka");
        address1.setHouseNo("217");
        address1.setRoadNo("10");
        address1.setZipCode("1201");
        
        contact1.setEmail("asdf@gmail.com");
        contact1.setPhone("01234789654");
        
        address1.setContact(contact1);
        
        department1.setDepartment("CSE");
        department1.setDeptBuilding("CCC");
        
        s1.setName("R");
        s1.setSeid("123654");
        s1.setAge(24);
        s1.setAddress(address1);
        s1.setDeapartment(department1);
        
        courses.add(new Course("SPL", "CSE-121", 3));
        courses.add(new Course("APL", "CSE-123", 1));
        courses.add(new Course("CA", "CSE-133", 3));
        
        s1.setCourses(courses);
        
        for (Course i : s1.getCourses()){
            System.out.println(i);
        }
        
    }
    
}
