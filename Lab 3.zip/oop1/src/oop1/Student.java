
package oop1;

import java.util.ArrayList;

public class Student {
    private String name;
    private String seid;
    private int age;
    
    ArrayList <Course> courses;
    
    private StudentAddress address;
    private StudentDepartment department;
      
    public Student(){
        
    }
    
    public Student(String name, String seid){
        this.name = name;
        this.seid = seid;
    }

    public Student(String name, String seid, String phone, int age) {
        this.name = name;
        this.seid = seid;
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSeid(String seid) {
        this.seid = seid;
    }

    public void setAge(int age) {
        if (age > 0){
            this.age = age;
        }
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public void setAddress(StudentAddress address) {
        this.address = address;
    }

    public void setDeapartment(StudentDepartment deapartment) {
        this.department = deapartment;
    }

    public String getName() {
        return name;
    }

    public String getSeid() {
        return seid;
    }

    public int getAge() {
        return age;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public StudentAddress getAddress() {
        return address;
    }

    public StudentDepartment getDeapartment() {
        return department;
    }

    public String getInfo(){
        return name +" "+ seid +" "+ age;
    }

    @Override
    public String toString() {
        return "Student{" + "name=" + name + ", seid=" + seid + ", age=" + age + ", courses=" + courses + ", address=" + address + ", department=" + department + '}';
    }

    
}
