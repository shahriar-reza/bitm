/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop1;

/**
 *
 * @author Mobile App Develop
 */
public class StudentDepartment {
        
    private String department;
    private String deptBuilding;

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDeptBuilding(String deptBuilding) {
        this.deptBuilding = deptBuilding;
    }

    public String getDepartment() {
        return department;
    }

    public String getDeptBuilding() {
        return deptBuilding;
    }

    @Override
    public String toString() {
        return "StudentDepartment{" + "department=" + department + ", deptBuilding=" + deptBuilding + '}';
    }
    
    
}
