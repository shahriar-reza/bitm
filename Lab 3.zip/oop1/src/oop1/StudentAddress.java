/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop1;

/**
 *
 * @author Mobile App Develop
 */
public class StudentAddress {
        
    private String houseNo;
    private String roadNo;
    private String city;
    private String zipCode;    
    
    private StudentContact contact;

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public void setRoadNo(String roadNo) {
        this.roadNo = roadNo;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public void setContact(StudentContact contact) {
        this.contact = contact;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public String getRoadNo() {
        return roadNo;
    }

    public String getCity() {
        return city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public StudentContact getContact() {
        return contact;
    }

    @Override
    public String toString() {
        return "StudentAddress{" + "houseNo=" + houseNo + ", roadNo=" + roadNo + ", city=" + city + ", zipCode=" + zipCode + ", contact=" + contact + '}';
    }
    
    
}
