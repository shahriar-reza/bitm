
package oop1;

public class Course {
    private String courseName;
    private String courseCode;
    private int courseCredit;

    public Course(String courseName, String courseCode, int courseCredit) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.courseCredit = courseCredit;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public void setCourseCredit(int courseCredit) {
        this.courseCredit = courseCredit;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public int getCourseCredit() {
        return courseCredit;
    }

    @Override
    public String toString() {
        return "Course{" + "courseName=" + courseName + ", courseCode=" + courseCode + ", courseCredit=" + courseCredit + '}';
    }
    
    
}
