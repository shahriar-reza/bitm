/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2;

/**
 *
 * @author Mobile App Develop
 */
public class PublicationInfo {
        
    private String publicationName;
    private String publicationYear;
    
    private PublicationAddress publicationAddress;

    public void setPublicationName(String publicationName) {
        this.publicationName = publicationName;
    }

    public void setPublicationYear(String publicationYear) {
        this.publicationYear = publicationYear;
    }

    public void setPublicationAddress(PublicationAddress publicationAddress) {
        this.publicationAddress = publicationAddress;
    }


    public String getPublicationName() {
        return publicationName;
    }

    public String getPublicationYear() {
        return publicationYear;
    }

    public PublicationAddress getPublicationAddress() {
        return publicationAddress;
    }

    @Override
    public String toString() {
        return "PublicationInfo{" + "publicationName=" + publicationName + ", publicationYear=" + publicationYear + ", publicationAddress=" + publicationAddress + '}';
    }

}
