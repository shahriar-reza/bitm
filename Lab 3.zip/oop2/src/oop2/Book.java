/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2;

import java.util.ArrayList;

/**
 *
 * @author Mobile App Develop
 */
public class Book {
    private String bookName;
    private String isbn;
    private String price;
    
    ArrayList <AuthorInfo> authorInfo;
   
    private PublicationInfo publicaitonInfo;
    private AdditionalInfo additionalInfo;
 
    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setAuthorInfo(ArrayList<AuthorInfo> authorInfo) {
        this.authorInfo = authorInfo;
    }

    public void setPublicaitonInfo(PublicationInfo publicaitonInfo) {
        this.publicaitonInfo = publicaitonInfo;
    }

    public void setAdditionalInfo(AdditionalInfo additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getBookName() {
        return bookName;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPrice() {
        return price;
    }

    public ArrayList<AuthorInfo> getAuthorInfo() {
        return authorInfo;
    }

    public PublicationInfo getPublicaitonInfo() {
        return publicaitonInfo;
    }

    public AdditionalInfo getAdditionalInfo() {
        return additionalInfo;
    }

    @Override
    public String toString() {
        return "Book{" + "bookName=" + bookName + ", isbn=" + isbn + ", price=" + price + ", authorInfo=" + authorInfo + ", publicaitonInfo=" + publicaitonInfo + ", additionalInfo=" + additionalInfo + '}';
    }
    
    
}
