/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2;

/**
 *
 * @author Mobile App Develop
 */
public class PublicationAddress {
    private String houseNo;
    private String roadNo;
    private String city;
    private String zipCode;    

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public void setRoadNo(String roadNo) {
        this.roadNo = roadNo;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public String getRoadNo() {
        return roadNo;
    }

    public String getCity() {
        return city;
    }

    public String getZipCode() {
        return zipCode;
    }

    @Override
    public String toString() {
        return "PublicationAddess{" + "houseNo=" + houseNo + ", roadNo=" + roadNo + ", city=" + city + ", zipCode=" + zipCode + '}';
    }

}
