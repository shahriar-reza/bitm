/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2;

/**
 *
 * @author Mobile App Develop
 */
public class AdditionalInfo {
        
    private String category;
    private String version;
    private String language;  

    public void setCategory(String category) {
        this.category = category;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCategory() {
        return category;
    }

    public String getVersion() {
        return version;
    }

    public String getLanguage() {
        return language;
    }

    @Override
    public String toString() {
        return "AdditionalInfo{" + "category=" + category + ", version=" + version + ", language=" + language + '}';
    }
    
    
}
