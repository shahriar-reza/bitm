
package oop2;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {

    public static void main(String[] args) {
    
    // Book object 1    
        Book b1 = new Book();
        ArrayList <AuthorInfo> authorList = new ArrayList<>();
        //AuthorInfo author1 = new AuthorInfo();
        PublicationInfo publication1 = new PublicationInfo();
        AdditionalInfo additional1 = new AdditionalInfo();
        PublicationAddress publicationAddress1 = new PublicationAddress();
        
        Scanner scanInt = new Scanner(System.in);
        Scanner scanString = new Scanner(System.in);
        
        System.out.println("    Book Registration System    ");
        System.out.println("________________________________");
        
        System.out.println("Book name:");
        String bookName = scanString.nextLine();
        
        System.out.println("Book ISBN:");
        String bookISBN = scanString.nextLine();
        
        System.out.println("Book Price:");
        String bookPrice = scanString.nextLine();
        
        System.out.println("Number of Authors:");
        int authorNumber = scanInt.nextInt();
        
        for (int i = 0; i < authorNumber; i++){
            System.out.println("Enter Details of Author " + (i+1));
            System.out.println("    Author"+(i+1)+" name:");
            String authorName = scanString.nextLine();
            System.out.println("    Author"+(i+1)+" Email:");
            String authorEmail = scanString.nextLine();
            System.out.println("    Author"+(i+1)+" Contact:");
            String authorContactNo = scanString.nextLine();
            
            authorList.add(new AuthorInfo(authorName, authorEmail, authorContactNo));
        }
        
        System.out.println("Publication Name:");
        String publicationName = scanString.nextLine();
        System.out.println("Publication Year:");
        String publicationYear = scanString.nextLine();
        
        System.out.println("Enter Detailed Publication Address");
        System.out.println("    House No:");
        String publicationHouseNo = scanString.nextLine();
        System.out.println("    Road No:");
        String publicationRoadNo = scanString.nextLine();
        System.out.println("    City:");
        String publicationCity = scanString.nextLine();
        System.out.println("    Zip  Code:");
        String publicationZipCode = scanString.nextLine();
        
        
        System.out.println("Category Name:");
        String bookCategory = scanString.nextLine();
        System.out.println("Version:");
        String bookVersion = scanString.nextLine();
        System.out.println("Language:");
        String bookLanguage = scanString.nextLine();
        
        
        b1.setBookName(bookName);
        b1.setIsbn(bookISBN);
        b1.setPrice(bookPrice);
        
        publication1.setPublicationName(publicationName);
        publication1.setPublicationYear(publicationYear);
        
        publicationAddress1.setCity(publicationCity);
        publicationAddress1.setHouseNo(publicationHouseNo);
        publicationAddress1.setRoadNo(publicationRoadNo);
        publicationAddress1.setZipCode(publicationZipCode);
        
        additional1.setCategory(bookCategory);
        additional1.setLanguage(bookLanguage);
        additional1.setVersion(bookVersion);
        
        publication1.setPublicationAddress(publicationAddress1);
        b1.setAdditionalInfo(additional1);
        b1.setPublicaitonInfo(publication1);
        
        b1.setAuthorInfo(authorList);
        
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("-----------------------------");
        
//        for (AuthorInfo i : b1.getAuthorInfo()){
//            System.out.println(i);
//        }
/*
    // Book object 2    
        Book b2 = new Book();
        AuthorInfo author2 = new AuthorInfo();
        PublicationInfo publication2 = new PublicationInfo();
        AdditionalInfo additional2 = new AdditionalInfo();
        PublicationAddress publicationAddress2 = new PublicationAddress();
        
        b2.setBookName("C");
        b2.setIsbn("SBN-126456");
        b2.setPrice("250 Tk");
        
        author2.setAuthorName("Clifton");
        author2.setAuthorEmail("clifton@outlook.com");
        author2.setAuthorContactNo("+990745215784");
        
        publication2.setPublicationName("Boighor Publication");
        publication2.setPublicationYear("2010");
        
        publicationAddress2.setCity("Dhaka");
        publicationAddress2.setHouseNo("212/A");
        publicationAddress2.setRoadNo("10/A");
        publicationAddress2.setZipCode("1208");
        
        additional2.setCategory("CSE");
        additional2.setLanguage("English");
        additional2.setVersion("7");
        
        publication2.setPublicationAddress(publicationAddress2);
        
        b2.setAuthorInfo(author2);
        b2.setAdditionalInfo(additional2);
        b2.setPublicaitonInfo(publication2);
        */
    //ArrayList    
        ArrayList <Book> bookList = new ArrayList<>();
        
        bookList.add(b1);
        //bookList.add(b2);
        
        for(Book i: bookList){
            System.out.println(i);
        }
    }
    
}
