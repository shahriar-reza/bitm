/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2;

/**
 *
 * @author Mobile App Develop
 */
public class AuthorInfo {
        
    private String authorName;
    private String authorEmail;
    private String authorContactNo; 

    public AuthorInfo(String authorName, String authorEmail, String authorContactNo) {
        this.authorName = authorName;
        this.authorEmail = authorEmail;
        this.authorContactNo = authorContactNo;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setAuthorEmail(String authorEmail) {
        this.authorEmail = authorEmail;
    }

    public void setAuthorContactNo(String authorContactNo) {
        this.authorContactNo = authorContactNo;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getAuthorEmail() {
        return authorEmail;
    }

    public String getAuthorContactNo() {
        return authorContactNo;
    }

    @Override
    public String toString() {
        return "AuthorInfo{" + "authorName=" + authorName + ", authorEmail=" + authorEmail + ", authorContactNo=" + authorContactNo + '}';
    }
    
    
}
