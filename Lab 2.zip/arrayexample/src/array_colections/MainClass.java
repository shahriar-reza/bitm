
package array_colections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class MainClass {
    
    public static void main(String[] args) {
    
    // array declaration    
        int[] x = new int[10];
        int[] y = {1,2,3};
        /*
        for(int i = 0; i < x.length; i++){
            x[i] = i+1;
        }
        for(int i:x){
            System.out.println(i);
        }
        */
        
        Random rand = new Random();
        //int rNum = rand.nextInt(100); //random 0 to 100
        int [][] z = new int[2][2];
        
        for (int[] z1 : z) {
            for (int j = 0; j < z.length; j++) {
                z1[j] = 1 + rand.nextInt(999);
            }
        }
        for(int i = 0; i < z.length; i++){
            for(int j = 0; j < z.length; j++){
                System.out.print(z[i][j] + " ");
            }
            System.out.println();
        }
        
        
        ArrayList <String> cities = new ArrayList<>();
        cities.add("Dhaka");
        cities.add("Chittagong");
        cities.add("Khulna");
        cities.add(0 ,"Sylhet"); //data will not be replaced it will be just adjusted i.e. shifting
        cities.add(3 ,"Rangpur");
        
        System.out.println(cities.size());
        System.out.println(cities.get(1));
        
        for (String i : cities){
            System.out.println(i);
        }
        Collections.sort(cities);for (String i : cities){
            System.out.println(i);
        }
        
        
    }
}