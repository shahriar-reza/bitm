
package oop;

import java.util.ArrayList;

public class Oop {


    public static void main(String[] args) {
        
        Student s = new Student();
        s.name = "Asdf";
        s.seid = "465312";
        s.phone = "78945656654";
        s.age = 24;
        
        ArrayList <Student> as = new ArrayList<>();
        as.add(s);
        
//        for(Student i : as){
//            System.out.println(i.getInfo());
//        }
        System.out.println(s); //calling toString() method from Student class
        
        Student s1 = new Student("Qer", "231076", "789654123", 23);
        System.out.println(s1); 
        
        
    }
    
}
