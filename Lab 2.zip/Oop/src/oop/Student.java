/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author Mobile App Develop
 */
public class Student {
    
    public String name;
    public String seid;
    public String phone;
    public int age;
    
    public String getInfo(){
        return name +" "+ seid +" "+ phone +" "+ age;
    }

    public Student() {
        
    }
    
    public Student(String name, String seid, String phone, int age) {
        this.name = name;
        this.seid = seid;
        this.phone = phone;
        this.age = age;
    }

//condtructor Overloading
    public Student(String name, String seid) {
        this.name = name;
        this.seid = seid;
    }
    
    @Override
    public String toString() {
        return "Student{" + "name=" + name + ", seid=" + seid + ", phone=" + phone + ", age=" + age + '}';
    }
    
}
