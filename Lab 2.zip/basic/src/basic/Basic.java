
package basic;

public class Basic {

//methods
    public static void op(int x, int y){
        System.out.println("Sum: "+ (x+y));
        System.out.println("Sub: "+ (x-y));
        System.out.println("Mul: "+ (x*y));
        System.out.println("Div: "+ (x/y));
        System.out.println("Mod: "+ (x%y));
    }
    
    // overloading
    public static void op(double x, double y){
        System.out.println("Sum: "+ (x+y));
        System.out.println("Sub: "+ (x-y));
        System.out.println("Mul: "+ (x*y));
        System.out.println("Div: "+ (x/y));
        System.out.println("Mod: "+ (x%y));
    }
    
    
    public static void something(String... s){  //... means undefined number of paremeters
        System.out.println(s);
    }
    
    public static void add(int... s){  //... means undefined number of paremeters
        int sum = 0;
        //inhance for loop
        for(int n : s){   //n is the array that will start from index 0 & runs untill s.length
            sum += n;          
        }
        System.out.println("Sum: " + sum);
    }
    
    public static void high_low(int x, int y, int z){
        System.out.println("Highest number: ");
        if(x>y && x>z){
            System.out.println(x);
        }else if(y>x && y>z){
            System.out.println(y);
        }else if(z>x && z>y){
            System.out.println(z);
        }
        
        System.out.println("Lowest number: ");
        if(x<y && x<z){
            System.out.println(x);
        }else if(y<x && y<z){
            System.out.println(y);
        }else if(z<x && z<y){
            System.out.println(z);
        }
    }
    
    public static void even_odd(){
        for (int i = 1; i <= 20; i++){
            if(i%2 == 0){
                System.out.println("Even");
            }
            else{
                System.out.println("Odd");
            }
        }
    }
    
    
    public static void main(String[] args) {
    
/*
        int x = 10;
        int y = 12;
        double d = 20;
        float f = 198f;
        boolean b = true; 
        String s = "qwertyu";
        String ss = "qewrt";        
        
    //Conditional Statements
        if (x == y){
            System.out.println("Equal integers!!!");
        }else {
            System.out.println("Not Equal!!!");
        }
        
        if (s.equals(ss)){
            System.out.println("Equal strings!!!");
        }else {
            System.out.println("Not Equal!!!");
        }
        
    //loop
        for(int i = 0; i < 10; i++){
           System.out.println(i);
        }        
        while (x < 20){
            System.out.println(x);
            x++;
        }
        do{
            System.out.println(x);
            x++;
        }while(x < 20);
             
    //switch-case
        switch(x){
            case 12: 
                System.out.println(x);
                break;
            case 13:
                System.out.println(x);
                break;
            default:
                System.out.println(x);
                break;
        }
        
        op(10,12);
        op(1243,1324);
        something("qw", "affff", "tre");
        add(1,2,3);
        add(1,2);
        add(1,2,3,4);
        
*/
        
        high_low(65, 45, 20);
        even_odd();
    }
    
}
