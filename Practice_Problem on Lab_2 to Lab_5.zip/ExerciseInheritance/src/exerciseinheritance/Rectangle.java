/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciseinheritance;

/**
 *
 * @author Shahriar Reza
 */
public class Rectangle extends Shape{
    private double witdh;
    private double length;

    public Rectangle() {
        this.witdh = 1.0;
        this.length = 1.0;
    }
    
    public Rectangle(double witdh, double length) {
        this.witdh = witdh;
        this.length = length;
    }
    
    public Rectangle(double witdh, double length, String color, boolean filled) {
        super(color, filled);
        this.witdh = witdh;
        this.length = length;
    }

    public double getWitdh() {
        return witdh;
    }

    public void setWitdh(double witdh) {
        this.witdh = witdh;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
    
    public double getArea(){
        return (witdh * length);
    }
    
    public double getPerimeter(){
        return (2 * (length + witdh));
    }

    @Override
    public String toString() {
        return "A Rectangle with width=" + witdh +" and length="+ length +", which is a subclass of " + super.toString();
    }
    
}
