/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciseinterface;

/**
 *
 * @author Shahriar Reza
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println(circle.toString());
        System.out.println(circle.getRadius());
        System.out.println(circle.getArea());
        System.out.println(circle.getPerimeter());
        
        ResizeableCircle resizeableCircle = new ResizeableCircle(7);
        System.out.println(resizeableCircle.toString());
        System.out.println(resizeableCircle.getRadius());
        System.out.println(resizeableCircle.getArea());
        System.out.println(resizeableCircle.getPerimeter());
        
        resizeableCircle.resize(50);
        System.out.println(resizeableCircle.toString());
        System.out.println(resizeableCircle.getRadius());
        System.out.println(resizeableCircle.getArea());
        System.out.println(resizeableCircle.getPerimeter());
    }
    
}
