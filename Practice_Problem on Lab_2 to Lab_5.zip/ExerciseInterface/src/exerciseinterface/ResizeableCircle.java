/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciseinterface;

/**
 *
 * @author Shahriar Reza
 */
public class ResizeableCircle extends Circle implements Resizeable {
 
    // Constructor
    public ResizeableCircle(double radius) {
       super(radius);
    }
 
    // Implement methods defined in the interface Resizeable
    @Override
    public double resize(int percent) {
        super.setRadius((super.getRadius()*percent)/100);
        return super.getRadius();
    }

    @Override
    public String toString() {
        return "ResizeableCircle{" + "radius=" + super.getRadius() + "area=" + super.getArea() + "Perimeter=" + super.getPerimeter() +'}';
    }
    
    
}
