
package inheritanceAbstractRuntimePolymorphismExample2;

public class MainClass {

    public static void main(String[] args) {
        
        //Employee e = new Employee("name", "id-123654");
        Employee bse = new BaseSalariedEmployee(50000,"Q", "ID-1");
        Employee hse = new HourlySalariedEmployee(50,500, "W", "ID-2");
        Employee bpce = new BasePlusCommissionedEmployee(50000,100000, 2.5, "E", "ID-3");
        Employee hpce = new HourlyPlusCommissionedEmployee(60,300,100000, 2.5, "R", "ID-4");
        
        /*//System.out.println(e.getClass().getSimpleName() + ":" +  " Name: " + e.getEmployee_name() + " ID: " + e.getEmployee_id() + " Total Earning: " + e.total_earnings());
        System.out.println(bse.getClass().getSimpleName() + ":" +  " Name: " + bse.getEmployee_name() + " ID: " + bse.getEmployee_id() + " Total Earning: " +   bse.total_earnings());
        System.out.println(hse.getClass().getSimpleName() + ":" +  " Name: " + hse.getEmployee_name() + " ID: " + hse.getEmployee_id() + " Total Earning: " +   hse.total_earnings());
        System.out.println(bpce.getClass().getSimpleName() + ":" +  " Name: " + bpce.getEmployee_name() + " ID: " + bpce.getEmployee_id() + " Total Earning: " + bpce.total_earnings());
        System.out.println(hpce.getClass().getSimpleName() + ":" +  " Name: " + hpce.getEmployee_name() + " ID: " + hpce.getEmployee_id() + " Total Earning: " +  hpce.total_earnings());
        */
        
        Employee[] em = {bse, hse, bpce, hpce};
        for(Employee e : em){
            System.out.println(e.getClass().getSimpleName() + ":" +  " Name: " + e.getEmployee_name() + "; ID: " + e.getEmployee_id() + "; Total Earning: " +   e.total_earnings());
        }
        
    }
    
}
