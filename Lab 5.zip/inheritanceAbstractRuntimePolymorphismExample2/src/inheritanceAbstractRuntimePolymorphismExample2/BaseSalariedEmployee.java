/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceAbstractRuntimePolymorphismExample2;

/**
 *
 * @author Mobile App Develop
 */
public class BaseSalariedEmployee extends Employee{
    private double salary;

    public BaseSalariedEmployee(double salary, String employee_name, String employee_id) {
        super(employee_name, employee_id);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public double total_earnings() {
        return salary;
    }
    
    
}
