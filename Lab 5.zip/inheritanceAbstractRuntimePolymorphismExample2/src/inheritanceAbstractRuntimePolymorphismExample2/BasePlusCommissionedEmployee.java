/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceAbstractRuntimePolymorphismExample2;

/**
 *
 * @author Mobile App Develop
 */
public class BasePlusCommissionedEmployee extends Employee{
    private double salary;
    private double gross_sale;
    private double com_rate;

    public BasePlusCommissionedEmployee(double salary, double gross_sale, double com_rate, String employee_name, String employee_id) {
        super(employee_name, employee_id);
        this.salary = salary;
        this.gross_sale = gross_sale;
        this.com_rate = com_rate;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getGross_sale() {
        return gross_sale;
    }

    public void setGross_sale(double gross_sale) {
        this.gross_sale = gross_sale;
    }

    public double getCom_rate() {
        return com_rate;
    }

    public void setCom_rate(double com_rate) {
        this.com_rate = com_rate;
    }

    @Override
    public double total_earnings() {
        return (salary + ((gross_sale*com_rate)/100));
    }
    
    
}
