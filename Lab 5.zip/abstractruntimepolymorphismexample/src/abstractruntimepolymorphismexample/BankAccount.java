
package abstractruntimepolymorphismexample;

public abstract class BankAccount {
    private String accountNumber;
    private String accountName;
    private double balance;
    public static String bankName;

    public BankAccount(String accountNumber, String accountName, double balance) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = balance;
        bankName = bankName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    public String deposit(double amount){
        balance += amount;
        return "Your Account has been credited by TK: "+amount;
    }
    
    /*public String withdrwal(double amount){
    //        if(balance - amount >= 500){
    //        balance -= amount;
    //        return "Your Account has been debited by Tk: "+amount;
    //        }
    //        else
    //        return "Insufficient fund!!";
    
    balance -= amount;
    return "Your Account has been debited by Tk: "+amount;
    
    }*/
    
    public abstract String withdrawl(double amount);
    
    
    public static String getBankName() {
        return bankName;
    }
 
    
    // this method can be called by child but cannot be overrided
    public final void bankInfo(){
        
    }
    
    /*
    *   final class cannot be extended but object of that class can be created
    */
    
}
