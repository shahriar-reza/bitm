
package abstractruntimepolymorphismexample;

public class MainClass {

    public static void main(String[] args) {
        
        SavingsAccount sa = new SavingsAccount(2.5, "SA-123654", "Richard", 500);
        CheckingAccount ca = new CheckingAccount(1500, "CA-987456", "Aiken", 5000);
        
        /*System.out.println(sa.getClass().getSimpleName() + ":" + sa.deposit(5000));
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.getBalance());
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.deposit(10000));
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.getBalance());
        
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.withdrawl(50000));
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.getBalance());
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.withdrawl(100000));
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.getBalance());*/
        
        /*    // Runtime polymorphism; condition: all the child class must override a common method
        BankAccount[] ba = {sa, ca};
        for (BankAccount b : ba){
        System.out.println(b.getClass().getSimpleName() +  ":" + b.withdrawl(2500));
        System.out.println(b.getClass().getSimpleName() + ":" + b.getBalance());
        }*/
        
        /*    // anonymous class
        BankAccount bank = new BankAccount("NO", "NAME", 1000){
        
        @Override
        public String withdrawl(double amount) {
        return "Anonymous Inner Class";
        }
        };
        System.out.println(bank.getClass().getSimpleName() +  ":" + bank.withdrawl(50000));*/
        
    // satic keyword: to access that properties no need to create object of that class as all static properties are class property     
        BankAccount.bankName = "";
        System.out.println(BankAccount.getBankName());
        
        
    //accessing static inner class and it's components    
        SavingsAccount.Nothing static_nothing = new SavingsAccount.Nothing();
        System.out.println(static_nothing.nothing);
        
    //accessing nos-static inner class and it's components    
        SavingsAccount.NonStaicNothing nonStaticNothing = sa.new NonStaicNothing();
        System.out.println(nonStaticNothing.nSNothing);
        
    }
    
}
