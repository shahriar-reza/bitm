
package interfaceexample;

public interface InterfaceA {
    void doSomething();
    void printName();
    
//method with a body in interface need to use dafault, static keyword
    default void printAge(){
        //body
    }
    
    static void something(){
        //body
    } 
}
