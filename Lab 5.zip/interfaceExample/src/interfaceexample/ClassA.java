
package interfaceexample;

public class ClassA implements InterfaceA {

    @Override
    public void doSomething() {
        System.out.println("In Class A");
    }

    @Override
    public void printName() {
        // body
    }
    
    public int add(int a, int b){
        return a+b;
    }
    
}
