
package interfaceexample;

public class MainClass {

    public static void main(String[] args) {
        InterfaceA a1 = new ClassA();//only overrided methods can be found by a1 object, add() cannot be found by a1.add()
        //  ClassA iAimpl = new ClassA();
        InterfaceA b1 = new ClassB();
        
        ClassA cA = new ClassA();
        System.out.println(cA.add(5,56));
        
        a1.doSomething();
        b1.doSomething();
        
        InterfaceA ia =  new InterfaceA(){

            @Override
            public void doSomething() {
                // something
            }

            @Override
            public void printName() {
                // something
            }
        };
        
        
        
        AddNumber aN = new AddNumber();
    // way 1: by anonymous class
        aN.add(new AddNumberListener(){

            @Override
            // call back method
            public void onFinished(int sum) {
                System.out.println(sum);
            }
            
        });
    // way 2: by class that implements AddNumberListener    
        aN.add(new Bitm());
        
    }
    
}
