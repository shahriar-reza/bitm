
package interfaceexample;

public class ClassB implements InterfaceA{

    @Override
    public void doSomething() {
        System.out.println("In Class B");
    }

    @Override
    public void printName() {
        // body
    }
    
}
