/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceexample;

/**
 *
 * @author Mobile App Develop
 */
public class AddNumber {
    public void add(AddNumberListener listener){
        int sum = 5 + 7;
        listener.onFinished(sum);
    }
}
