/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceexample2;

/**
 *
 * @author Mobile App Develop
 */
public class HourlySalariedEmployee extends Employee{
    private double total_hour;
    private double hour_rate;

    public HourlySalariedEmployee(double total_hour, double hour_rate, String employee_name, String employee_id) {
        super(employee_name, employee_id);
        this.total_hour = total_hour;
        this.hour_rate = hour_rate;
    }

    public double getTotal_hour() {
        return total_hour;
    }

    public void setTotal_hour(double total_hour) {
        this.total_hour = total_hour;
    }

    public double getHour_rate() {
        return hour_rate;
    }

    public void setHour_rate(double hour_rate) {
        this.hour_rate = hour_rate;
    }

    @Override
    public double total_earnings() {
        return total_hour * hour_rate;
    }
    
    
}
