/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceexample2;

/**
 *
 * @author Mobile App Develop
 */
public class HourlyPlusCommissionedEmployee extends Employee{
    private double total_hour;
    private double hour_rate;
    private double gross_sale;
    private double com_rate;

    public HourlyPlusCommissionedEmployee(double total_hour, double hour_rate, double gross_sale, double com_rate, String employee_name, String employee_id) {
        super(employee_name, employee_id);
        this.total_hour = total_hour;
        this.hour_rate = hour_rate;
        this.gross_sale = gross_sale;
        this.com_rate = com_rate;
    }

    public double getTotal_hour() {
        return total_hour;
    }

    public void setTotal_hour(double total_hour) {
        this.total_hour = total_hour;
    }

    public double getHour_rate() {
        return hour_rate;
    }

    public void setHour_rate(double hour_rate) {
        this.hour_rate = hour_rate;
    }

    public double getGross_sale() {
        return gross_sale;
    }

    public void setGross_sale(double gross_sale) {
        this.gross_sale = gross_sale;
    }

    public double getCom_rate() {
        return com_rate;
    }

    public void setCom_rate(double com_rate) {
        this.com_rate = com_rate;
    }

    @Override
    public double total_earnings() {
        return (total_hour * hour_rate) + ((gross_sale*com_rate)/100);
    }
    
    
}
