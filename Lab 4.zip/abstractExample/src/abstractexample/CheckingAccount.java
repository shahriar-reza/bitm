
package abstractexample;

public class CheckingAccount extends BankAccount{
    private double serviceCharge;

    public CheckingAccount(double serviceCharge, String accountNumber, String accountName, double balance) {
        super(accountNumber, accountName, balance);
        this.serviceCharge = serviceCharge;
    }

    public double getServiceCharge() {
        return serviceCharge;
    }

    public void setServiceCharge(double serviceCharge) {
        this.serviceCharge = serviceCharge;
    }

    @Override
    public String withdrawl(double amount) {
        super.setBalance(super.getBalance() - amount);
        return "Your Account has been debited by Tk: "+amount;
    }
    
    
}
