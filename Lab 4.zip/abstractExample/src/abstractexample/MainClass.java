
package abstractexample;

public class MainClass {

    public static void main(String[] args) {
        
        SavingsAccount sa = new SavingsAccount(2.5, "SA-123654", "Richard", 500);
        CheckingAccount ca = new CheckingAccount(1500, "CA-987456", "Aiken", 5000);
        
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.deposit(5000));   
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.getBalance());  
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.deposit(10000));
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.getBalance());
        
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.withdrawl(50000));   
        System.out.println(sa.getClass().getSimpleName() + ":" + sa.getBalance());  
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.withdrawl(100000));
        System.out.println(ca.getClass().getSimpleName() + ":" + ca.getBalance());
        
    }
    
}
