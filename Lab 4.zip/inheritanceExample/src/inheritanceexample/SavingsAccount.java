
package inheritanceexample;

public class SavingsAccount extends BankAccount{
    private double interestRate;

    public SavingsAccount(double interestRate, String accountNumber, String accountName, double balance) {
        super(accountNumber, accountName, balance);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public String withdrwal(double amount) {
        if(super.getBalance() - amount >= 500){
            super.setBalance(super.getBalance() - amount);
            return "Your Account has been debited by Tk: "+amount;
        }
        else
            return "Insufficient fund!!";
    }
    
    
}
